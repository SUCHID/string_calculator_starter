package com.cybage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JiraCloudRestApiIntegrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(JiraCloudRestApiIntegrationApplication.class, args);
	}

}
